/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: PartsController.java
 */

package controller;

import io.IExporter;
import io.IImporter;
import io.exporting.JSONExporter;
import io.exporting.JavaExporter;
import io.exporting.XMLExporter;
import io.importing.JSONImporter;
import io.importing.JavaImporter;
import io.importing.XMLImporter;
import model.CarPart;
import model.PartsModel;

import java.util.Collection;

/**
 * PartsController class to interact with the PartsModel and PartsUI
 */
public class PartsController
{
    private PartsModel model;

    /**
     * PartsController class to interact with the PartsModel and PartsUI
     */
    public PartsController()
    {
        model = new PartsModel();
    }

    /**
     * Adds a car part to a CarPat class
     *
     * @param id of car part
     * @param manufacturer of car part
     * @param listPrice of car part
     */
    public void addPart(String id, String manufacturer, double listPrice)
    {
        //add a new part to the PartsModel
        model.addPart(new CarPart(id, manufacturer, listPrice));
    }

    /**
     * Returns a Collection of car parts
     *
     * @return Collection<CarPart>
     */
    public Collection<CarPart> getParts()
    {
        //retrieve all parts from the PartsModel
        return model.getParts();
    }

    /**
     * Imports parts to the selected file store
     *
     * @param strategy of file import
     */
    public void importParts(String strategy)
    {
        //import parts according to the strategy given
        if(strategy.equalsIgnoreCase("Java")){
            JavaImporter javaImporter = new JavaImporter(model);
            javaImporter.importParts(model);

        }
        if(strategy.equalsIgnoreCase("JSON")){
            JSONImporter jsonImporter = new JSONImporter(model);
            jsonImporter.importParts(model);

        }
        if(strategy.equalsIgnoreCase("XML")){
            XMLImporter xmlImporter = new XMLImporter(model);
            xmlImporter.importParts(model);

        }

    }

    /**
     *  Exports parts to the selected file store
     *
     * @param strategy of file export
     */
    public void exportParts(String strategy)
    {
        //Export parts according to the strategy given
        if(strategy.equalsIgnoreCase("Java")){
            JavaExporter exporter = new JavaExporter(model);
            exporter.exportParts(model);

        }
        if(strategy.equalsIgnoreCase("JSON")){
            JSONExporter jsonExporter = new JSONExporter(model);
            jsonExporter.exportParts(model);

        }
        if(strategy.equalsIgnoreCase("XML")){
            XMLExporter xmlExporter = new XMLExporter(model);
            xmlExporter.exportParts(model);

        }
    }
}
