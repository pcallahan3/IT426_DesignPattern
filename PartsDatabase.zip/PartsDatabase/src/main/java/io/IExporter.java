package io;

import model.PartsModel;

public interface IExporter
{
    public void exportParts(PartsModel data);
}
