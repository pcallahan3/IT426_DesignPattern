package io;

import model.PartsModel;

public interface IImporter
{
    public void importParts(PartsModel data);
}
