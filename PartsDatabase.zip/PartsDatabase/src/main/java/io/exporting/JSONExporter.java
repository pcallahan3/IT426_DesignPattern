/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: JSONExporter.java
 */

package io.exporting;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.IExporter;
import model.PartsModel;

import java.io.FileWriter;
import java.io.IOException;

/**
 * JSONExporter class that implements the IExporter interface to export selected data into a JSON file format
 * to turn a Java object into a JSON object
 */
public class JSONExporter implements IExporter {

    private PartsModel parts;
    Gson gson = new Gson();

    /**
     * JSONExporter class that interacts with a PartsModel
     *
     * @param parts of PartsModel
     */
    public JSONExporter(PartsModel parts) {

        this.parts = parts;

    }

    /**
     * Creates and writes a new JSON file
     *
     * @param data of PartsModel
     */
    public void exportParts(PartsModel data) {

        //Convert object to JSON string
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(data);
        System.out.println("| File saved in JSON format! |");
        System.out.println("-------------------------------");

        //Convert object to JSON string and save into a file directly
        try (FileWriter writer = new FileWriter("parts.json")) {
            gson.toJson(data, writer);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
