/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: JavaExporter.java
 */


package io.exporting;

import controller.PartsController;
import io.IExporter;
import model.CarPart;
import model.PartsModel;

import java.io.*;
import java.util.Calendar;
import java.util.Collection;

/**
 * JavaExporter class that implements the IExporter interface to export/write selected data into a dat file format
 */
public class JavaExporter implements IExporter {


    private static final long serialVersionUID = 1L;
    private PartsModel parts;

    /**
     * JavaExporter class that interacts with the PartsModel
     *
     * @param parts of PartsModel
     */
    public JavaExporter(PartsModel parts) {

        this.parts = parts;

    }

    /**
     * Creates and writes a new dat file
     *
     * @param data of PartsModel
     */
    public void exportParts (PartsModel data){

            try {
                FileOutputStream partsJSON = new FileOutputStream("parts.dat");
                ObjectOutputStream readParts = new ObjectOutputStream(partsJSON);
                readParts.writeObject(data.getParts());
                readParts.close();
                System.out.println("| File saved as a Java object! |");
                System.out.println("---------------------------------");

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

