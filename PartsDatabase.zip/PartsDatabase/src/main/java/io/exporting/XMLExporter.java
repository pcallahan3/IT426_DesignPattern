/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: XMLExporter.java
 */


package io.exporting;

import io.IExporter;
import model.CarPart;
import model.PartsModel;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;

/**
 *  XMLEporter class that implements the IExporter interface to export selected data to a XML file format
 */
public class XMLExporter implements IExporter {

    private PartsModel parts;


    /**
     * XMLExporter class to interact with a PartsModel
     *
     * @param parts of PartsModel
     */
    public XMLExporter(PartsModel parts) {
        this.parts = parts;

    }


    /**
     * Creates and writes to a new XML file
     *
     * @param data of PartsModel
     */
    public void exportParts(PartsModel data) {

        try {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // root elements
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("PartsDatabase");
            doc.appendChild(rootElement);

            //parts elements
            Element parts = doc.createElement("parts");
            rootElement.appendChild(parts);

            //id elements
            Element id = doc.createElement("id");
            id.appendChild(doc.createTextNode( data.getParts().toString() + "\n"));
            parts.appendChild(id);

            // manufacturer elements
            Element manufacturer = doc.createElement("manufacturer");
            manufacturer.appendChild(doc.createTextNode(data.getParts().toString() + "\n" ));
            parts.appendChild(manufacturer);

            //list price elements
            Element price = doc.createElement("listprice");
            price.appendChild(doc.createTextNode(data.getParts().toString() + "\n" ));
            parts.appendChild(price);

            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("parts.xml"));

            // Output to console for testing
            //StreamResult result = new StreamResult(System.out);
            transformer.transform(source, result);
            System.out.println("| File saved in XML format! |");
            System.out.println("------------------------------");

        } catch (ParserConfigurationException pce) {
            pce.printStackTrace();
        } catch (TransformerException tfe) {
            tfe.printStackTrace();
        }
    }
}



