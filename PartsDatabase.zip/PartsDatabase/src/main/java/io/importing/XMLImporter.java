/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: XMLImporter.java
 */

package io.importing;

import io.IImporter;
import model.PartsModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

/**
 *
 *  XMLImporter class that implements the IExporter interface to import selected data to read from a XML file format
 */
public class XMLImporter implements IImporter {

    private PartsModel parts;


    /**
     *  XMLImporter class to interact with a PartsModel
     *
     * @param parts of PartsModel
     */
    public XMLImporter(PartsModel parts) {

        this.parts = parts;

    }

    /**
     * Reads an XML file
     *
     * @param data of PartsModel
     */
    public void importParts(PartsModel data) {

        try {

            File fXmlFile = new File("parts.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);

            doc.getDocumentElement().normalize();

            System.out.println("| Importing File! |");
            System.out.println("-------------------");
            System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("parts");
            for (int temp = 0; temp < nList.getLength(); temp++) {

                Node nNode = nList.item(temp);
                System.out.println("Current Element: " + nNode.getNodeName());

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("Parts: " + eElement.getAttribute("parts"));
                    System.out.println("Id: " + eElement.getElementsByTagName("id").item(0).getTextContent());
                    System.out.println("Manufacturer: " + eElement.getElementsByTagName("manufacturer").item(0).getTextContent());
                    System.out.println("List Price: " + eElement.getElementsByTagName("listprice").item(0).getTextContent());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}