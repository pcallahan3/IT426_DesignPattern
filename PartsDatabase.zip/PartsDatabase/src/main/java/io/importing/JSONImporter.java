/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: JSONImporter.java
 */

package io.importing;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.IImporter;
import model.PartsModel;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/**
 * JSONImporter class that implements the IImporter interface to import selected data from a JSON file format
 * to be converted into a Java object
 */
public class JSONImporter implements IImporter {

    private Gson gson = new GsonBuilder().create();
    private PartsModel parts;

    /**
     * JSONImporter class that interacts with a PartsModel
     *
     * @param parts of PartsModels
     */
    public JSONImporter(PartsModel parts) {

        this.parts = parts;

    }

    /**
     * Reads from a JSON file and converts a JSON object to a Java Object
     *
     * @param data of PartsModel
     */
    public void importParts(PartsModel data) {

        try (Reader reader = new FileReader("parts.json")) {

            // Convert JSON to Java Object
            PartsModel partsModel = gson.fromJson(reader, PartsModel.class);
            System.out.println("| Importing file! |");
            System.out.println("-------------------");
            System.out.println(partsModel.getParts());

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}

