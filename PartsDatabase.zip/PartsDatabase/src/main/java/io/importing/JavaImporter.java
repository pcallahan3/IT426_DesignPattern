/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: JavaImporter.java
 */


package io.importing;

import io.IImporter;
import model.PartsModel;

import java.io.*;

/**
 * JavaImporter class that implements the IImporter interface to import/read selected data into a dat file format
 */
public class JavaImporter implements IImporter {

    private static final long serialVersionUID = 42L;
    private PartsModel parts;

    /**
     * JavaImporter class that interacts with the PartsModel
     *
     * @param parts of PartsModel
     */
    public JavaImporter(PartsModel parts) {
        this.parts = parts;
    }


    /**
     * Reads a Java object from a dat file
     *
     * @param data of PartsModel
     */
    public void importParts(PartsModel data) {

        // The name of the file to open.
        String fileName = "parts.dat";

        // This will reference one line at a time
        String line = null;

        try {

            FileInputStream partsJSON = new FileInputStream("parts.dat");
            ObjectInputStream readParts = new ObjectInputStream(partsJSON);
            // FileReader reads text files in the default encoding.
            FileReader fileReader = new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader =
                    new BufferedReader(fileReader);

            System.out.println("| Importing file! |");
            System.out.println("--------------------");
            while((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
            bufferedReader.close();
        }
        catch(FileNotFoundException ex) {
           ex.getMessage();
        }
        catch(IOException ex) {
          ex.getMessage();
        }

    }
}
