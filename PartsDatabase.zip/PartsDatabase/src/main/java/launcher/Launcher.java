/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: Launcher.java
 */


package launcher;

import javafx.application.Application;
import view.PartsUI;

/**
 * Launcher class to launch application
 */
public class Launcher
{

    /**
     * Entry point into application
     *
     * @param args
     */
    public static void main(String[] args)
    {
        Application.launch(PartsUI.class, args);
    }
}
