package launcher;

import javafx.application.Application;
import view.PartsUI;

public class Launcher
{
    public static void main(String[] args)
    {
        Application.launch(PartsUI.class, args);
    }
}
