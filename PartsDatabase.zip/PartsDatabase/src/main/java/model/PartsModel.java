/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: PartsModel.java
 */


package model;

import io.IExporter;
import io.IImporter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * PartsModel class that is the model layer of the application
 */
public class PartsModel implements Serializable
{
    private Collection<CarPart> parts;

    /**
     * PartsModel constructor that stores and ArrayList of CarParts
     */
    public PartsModel()
    {
        parts = new ArrayList<CarPart>();
    }

    /**
     * Add a car part to the model
     *
     * @param part of a car part
     */
    public void addPart(CarPart part)
    {
        parts.add(part);
    }


    /**
     * Get car parts
     *
     * @return Collection<CarPart>
     */
    public Collection<CarPart> getParts()
    {
        return Collections.unmodifiableCollection(parts);
    }

    /**
     * Export/save data to specified file format
     *
     * @param exporter to file format
     */
    public void saveParts(IExporter exporter)
    {
        exporter.exportParts(this);
    }

    /**
     * Read/export data to a specified file format
     *
     * @param importer to a file format
     */
    public void loadParts(IImporter importer)
    {
        importer.importParts(this);
    }

    /**
     * Clear out car parts
     */
    public void clear()
    {
        parts.clear();
    }
}
