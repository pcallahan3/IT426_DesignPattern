/**
 * Name: Patrick Callahan
 * Date: 2/27/2018
 * FileName: CarPart.java
 */


package model;

import java.io.Serializable;

/**
 * CarPart class that implements Serializable that allows you to create CarParts and
 * store and id, manufacturer, and listPrice
 */
public class CarPart implements Serializable
{
    private String id;
    private String manufacturer;
    private double listPrice;

    /**
     * CarPart constructor that allows you to pass in id, manufacturer, and listPrice of car part
     *
     * @param id of car part
     * @param manufacturer of car part
     * @param listPrice of car part
     */
    public CarPart(String id, String manufacturer, double listPrice)
    {
        this.id = id;
        this.manufacturer = manufacturer;
        this.listPrice = listPrice;
    }

    /**
     * Get id of car part
     *
     * @return id of car part
     */
    public String getId()
    {
        return id;
    }

    /**
     * Get manufacturer of car part
     *
     * @return manufacturer of car part
     */
    public String getManufacturer()
    {
        return manufacturer;
    }


    /**
     * Set id of car part
     *
     * @param id of car part
     */
    public void setId(String id)
    {
        this.id = id;
    }

    /**
     * Set manufacturer of car part
     *
     * @param manufacturer of car part
     */
    public void setManufacturer(String manufacturer)
    {
        this.manufacturer = manufacturer;
    }


    /**
     * Get list price of car part
     *
     * @return listPrice of car part
     */
    public double getListPrice()
    {
        return listPrice;
    }


    /**
     * Set list price of car part
     *
     * @param listPrice of car part
     */
    public void setListPrice(double listPrice)
    {
        this.listPrice = listPrice;
    }

    /**
     * String repensentation of a CarPart object
     *
     * @return id, manufacturer, and list price of car part
     */
    public String toString()
    {
        return id + " - " + manufacturer + ": ($" + listPrice + ")";
    }
}
