package junit_practice;


public class SomeTestFile {


}
