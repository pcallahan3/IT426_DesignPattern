package shapes;

import javafx.scene.paint.Color;

/**
 * * Class to construct a Line
 *
 * @author Patrick Callahan
 * @version 1.0
 */
public class Line extends Shape
{
    private double x2;
    private double y2;

    /**
     *
     * @param x double
     * @param y doulbe
     * @param x2 diuble
     * @param y2 double
     * @param thickness double
     * @param color Color
     */
    public Line(double x, double y, double x2, double y2, double thickness, Color color)
    {
        super(x, y, thickness, color);

        this.x2 = x2;
        this.y2 = y2;
    }

    /**
     * Return 2nd X value of the line
     *
     * @return x2
     */
    public double getX2()
    {
        return x2;
    }

    /**
     *  Return 2nd X value of the line
     *
     * @return y2
     */
    public double getY2()
    {
        return y2;
    }

    /**
     * String repsentation of the line obeject
     *
     * @return x2 and y2
     */
    public String toString()
    {
        return "Line [x2=" + x2 + ", y2=" + y2 + " " + super.toString() + "]";
    }
}
