package shapes;

import javafx.scene.paint.Color;

/**
 * * Class to construct a Shape
 *
 * @author Patrick Callahan
 * @version 1.0
 */
public class Shape
{
    //location
    private double x;
    private double y;

    //shape drawing settings
    private double thickness;
    private Color color; //readonly

    /**
     * Class to constuct a Shape
     *
     * @param x double
     * @param y double
     * @param thickness double
     * @param color Color
     */
    public Shape(double x, double y, double thickness, Color color)
    {
        this.x = x;
        this.y = y;

        this.thickness = thickness;
        this.color = color;
    }

    /**
     * Return x value of shape
     *
     * @return x
     */
    public double getX()
    {
        return x;
    }

    /**
     * Return y value of shape
     *
     * @return y
     */
    public double getY()
    {
        return y;
    }

    /**
     * Return thickness value of shape
     *
     * @return thickness
     */
    public double getThickness()
    {
        return thickness;
    }

    /**
     * Return color of shape
     *
     * @return Color
     */
    public Color getColor()
    {
        return color;
    }

    /**
     * Set x value of shape
     *
     *@param x
     */
    public void setX(double x)
    {
        this.x = x;
    }

    /**
     * Set y value of shape
     *
     * @param y
     *
     */
    public void setY(double y)
    {
        this.y = y;
    }

    /**
     * Set thickness value of shape
     *
     * @param thickness
     */
    public void setThickness(double thickness)
    {
        this.thickness = thickness;
    }

    /**
     * Retrun a string representation of a Shape object
     *
     * @return x,y,thickness,Color
     */
    public String toString()
    {
        return "Shape [x=" + x + ", y=" + y + ", thickness=" + thickness + ", color=" + color + "]";
    }
}
