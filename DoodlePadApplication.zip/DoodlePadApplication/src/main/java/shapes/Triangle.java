package shapes;

import javafx.scene.paint.Color;


/**
 * * Class to construct a Triangle
 *
 * @author Patrick Callahan
 * @version 1.0
 */
public class Triangle extends Rectangle
{
    //triangles are defined according to their bounding box
    /**
     * Contructor for a triangle
     *
     * @param x
     * @param y
     * @param width
     * @param length
     * @param thickness
     * @param color
     */
    public Triangle(double x, double y, double width, double length, double thickness, Color color)
    {
        super(x, y, width, length, thickness, color);
    }
}
