package shapes;

import javafx.scene.paint.Color;


/**
 * * Class to construct a Rectangle
 *
 * @author Patrick Callahan
 * @version 1.0
 */
public class Rectangle extends Shape
{
    private double width;
    private double height;

    /**
     * Constructor for a Rectangle
     *
     * @param x double
     * @param y double
     * @param width double
     * @param height doulbe
     * @param thickness double
     * @param color Color
     */
    public Rectangle(double x, double y, double width, double height, double thickness, Color color)
    {
        super(x, y, thickness, color);

        this.width = width;
        this.height = height;
    }

    /**
     * Get width of rectangle
     *
     * @return width
     */
    public double getWidth()
    {
        return width;
    }

    /**
     * Get height of rectangle
     *
     * @return height
     */
    public double getHeight()
    {
        return height;
    }

    /**
     * String reprensetation of a rectangle
     *
     * @return width and height
     */
    public String toString()
    {
        return "Rectangle [width=" + width + ", height=" + height + " " + super.toString() + "]";
    }
}
