package shapes;

import javafx.scene.paint.Color;


/**
 * * Class to construct a Circle
 *
 * @author Patrick Callahan
 * @version 1.0
 */
public class Circle extends Shape
{
    private double radius;

    /**
     * Constructor for a Circle
     *
     * @param radius double
     * @param x double
     * @param y
     * @param thickness double
     * @param color Color
     */
    public Circle(double radius, double x, double y, double thickness, Color color)
    {
        super(x, y, thickness, color);

        this.radius = radius;
    }

    /**
     * Get radius of circle
     *
     * @return radius
     */
    public double getRadius()
    {
        return radius;
    }

    /**
     * String repsentation of the circle obeject
     *
     * @return radius
     */
    public String toString()
    {
        return "Circle [radius=" + radius + " " + super.toString() + "]";
    }
}
