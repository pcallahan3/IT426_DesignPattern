package launchers;

import javafx.application.Application;
import ui.DoodleUI;

/**
 * Main entry point into the application
*
* @author Patrick Callahan
* @version 1.0
*/
public class Launcher
{
    public static void main(String[] args)
    {
        Application.launch(DoodleUI.class, args);
    }
}
